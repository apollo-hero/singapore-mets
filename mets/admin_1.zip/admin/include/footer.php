    
                    <footer>
                       <!-- <hr>-->


                      <!--  <p>&copy; 2013 </p>-->
                    </footer>   
   
    <script src="lib/bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript">
        $("[rel=tooltip]").tooltip();
        $(function() {
            $('.demo-cancel-click').click(function(){return false;});
        });
    </script>
