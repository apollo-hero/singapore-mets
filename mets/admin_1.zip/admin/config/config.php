<?php
session_start();
ob_start();
//$timezone = "Asia/Calcutta";
//if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
$dbhost='localhost';
$default_dbname='mets_redo';
//$dbusern='gaap_vbis';
$dbusern='root';
//$dbuserp='vb!$!nd!@';
$dbuserp='';

$map_key="";
//$site_url	=	"http://gaap1.com/metsSite/";
$site_url	=	"http://localhost/metsSite/";
$site_title	=	"";
$encode =0;

$con = mysqli_connect($dbhost,$dbusern,$dbuserp,$default_dbname);


?>