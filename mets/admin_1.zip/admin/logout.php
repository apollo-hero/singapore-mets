<?
include("config/config.php");
include("config/function.php");
unset($_SESSION['ADMIN']);

header("location:index.php");
exit;
?>





